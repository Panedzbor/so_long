Hey,
Thanks for choosing my pack!

If you missed it, the license of this pack is Creative Commons 0
(aka Public Domain). That means that you can use it in personal,
educational, commercial and other projects.

The link to my profile is good, but fully optional. If you want
to put it, link to https://comigo.itch.io/, and call me CoMiGo.

You can also donate $3 USD or more and get the source project of it.
It can be opened with Gravit Designer, a freemium app that works
online and on desktop. Almost the whole asset pack was made with
its free version, so you will be able to create new sprites from
that project easier.

It will also help me create new asset packs, which is good <3
The source file can be purchased at
https://comigo.itch.io/farm-puzzle-animals

Happy coding!
~ CoMiGo
